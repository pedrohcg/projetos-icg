#include "Vertice.h"

Vertice::Vertice()
{
    //ctor
}

Vertice::~Vertice()
{
    //dtor
}
